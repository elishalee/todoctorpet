

import UIKit

class HospitalTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageHospital: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelRegion: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
             
        // 이미지 테두리 둥글게 바꾸는 코드
         self.imageHospital.layoutIfNeeded()
         self.imageHospital.layer.cornerRadius = self.imageHospital.frame.width/2.0
         self.imageHospital.clipsToBounds = true
             
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
