

import UIKit

class MyinfoViewController: UIViewController {

    @IBOutlet weak var profileImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.layoutIfNeeded()
        self.profileImage.layer.cornerRadius = self.profileImage.frame.width/2.0
        self.profileImage.clipsToBounds = true

  
    }
    


}
