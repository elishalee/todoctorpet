
import UIKit

class AppInfoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 상단 네비게이션 바 숨김
        self.navigationController?.isNavigationBarHidden = true


    }
    
    @IBAction func onBtnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    

}
