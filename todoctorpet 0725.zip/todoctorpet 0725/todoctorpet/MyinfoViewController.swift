

import UIKit

class MyinfoViewController: UIViewController {

    @IBOutlet weak var profileImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.layoutIfNeeded()
        self.profileImage.layer.cornerRadius = self.profileImage.frame.width/2.0
        self.profileImage.clipsToBounds = true

        
        // 상단 네비게이션 바 숨김
        self.navigationController?.isNavigationBarHidden = true
  
    }
    
    @IBAction func onBtnBack(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
    

}
