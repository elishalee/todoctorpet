
import UIKit
import Toast_Swift
import SDWebImage

class HospitalViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

     // labelName 레이블 출력 내용
        let names: Array<String> = ["test1",
                                    "test2",
                                    "test3",
                                    "test4",
                                    "test1",
                                    "test2",
                                    "test3",
                                    "test4"]
        
        // labelRegion 레이블 출력 내용
        let regions: Array<NSString> = ["test1",
                                        "test2",
                                        "test3",
                                        "test4",
                                        "test1",
                                        "test2",
                                        "test3",
                                        "test4"]
        
        // imageHospital 이미지뷰 출력 이미지
        let images: Array<String> =
            ["https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
            "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
            "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
            "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
            "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
            "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
            "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
            "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png"]
       
        // 토스트 알림 메시지 내용
        let messages: Array<String> = ["test1",
                                       "test2",
                                       "test3",
                                       "test4",
                                        "test1",
                                        "test2",
                                        "test3",
                                        "test4"]
        
        
        
        
        @IBOutlet weak var hospitalTableView: UITableView!
        
            override func viewDidLoad() {
                super.viewDidLoad()
                
                // 상단 네비게이션 바 숨김
                self.navigationController?.isNavigationBarHidden = true
            }
    
    @IBAction func onBtnBack(_ sender: Any) {
         self.navigationController?.popViewController(animated: true)
    }
    
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return self.names.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "hosptialTableViewCell", for: indexPath) as! HospitalTableViewCell
            cell.labelName.text = names[indexPath.row]
            cell.labelRegion.text = String(regions[indexPath.row])
            cell.imageHospital.sd_setImage(with: URL(string: self.images[indexPath.row]), completed: nil)
            cell.selectionStyle = .none
            
            return cell
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //        tableView.deselectRow(at: indexPath, animated: false)  // 눌려있지 않고 누르고 있을때만 음영표시
                print("\(indexPath.row)줄이 선택됨.")
                self.view.makeToast(messages[indexPath.row], duration: 2.0, position: .bottom)
            }
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                return 100
            }
        func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
                print("\(indexPath.row)줄이 선택됨")
                self.view.makeToast(self.messages[indexPath.row], duration: 2.0, position: .bottom)
            }

    }
