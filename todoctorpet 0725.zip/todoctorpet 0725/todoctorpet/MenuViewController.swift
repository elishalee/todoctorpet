
import UIKit


class MenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
     // 상단 네비게이션 바 숨김
     self.navigationController?.isNavigationBarHidden = true
    }
    



}
