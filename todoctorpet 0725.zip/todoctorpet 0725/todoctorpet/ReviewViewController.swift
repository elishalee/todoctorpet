
import UIKit

class ReviewViewController: UIViewController {

    @IBOutlet weak var reviewImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.layoutIfNeeded()
        self.reviewImage.layer.cornerRadius = self.reviewImage.frame.width/2.0
        self.reviewImage.clipsToBounds = true
        
        // 상단 네비게이션 바 숨김
        self.navigationController?.isNavigationBarHidden = true

    }
    
    @IBAction func onBtnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    

}
