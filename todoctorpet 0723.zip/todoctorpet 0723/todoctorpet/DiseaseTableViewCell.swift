
import UIKit

class DiseaseTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageAnimal: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelAnimal: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
   // 이미지 테두리 둥글게 바꾸는 코드
    self.imageAnimal.layoutIfNeeded()
    self.imageAnimal.layer.cornerRadius = self.imageAnimal.frame.width/2.0
    self.imageAnimal.clipsToBounds = true
        
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    
    }

}
