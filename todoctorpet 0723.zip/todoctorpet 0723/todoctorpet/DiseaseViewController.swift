
import UIKit
import Toast_Swift
import SDWebImage

class DiseaseViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    // labelName 레이블 출력 내용
    let names: Array<String> = ["test",
                                "test",
                                "test",
                                "test"]
    
    // labelAnimal 레이블 출력 내용
    let animals: Array<NSString> = ["고양이",
                                   "강아지",
                                   "햄스터",
                                   "토끼"]
    
    // imageAnimal 이미지뷰 출력 이미지
    let images: Array<String> = ["https://www.google.com/url?sa=i&url=https%3A%2F%2Fko.wikipedia.org%2Fwiki%2F%25ED%258C%258C%25EC%259D%25BC%3ACreative-Tail-Animal-cat.svg&psig=AOvVaw0vXYuWkrVKcCTyiRDvL4_b&ust=1595464013543000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCOid0OTM3-oCFQAAAAAdAAAAABAJ",
        "https://www.google.com/url?sa=i&url=https%3A%2F%2Fko.wikipedia.org%2Fwiki%2F%25ED%258C%258C%25EC%259D%25BC%3ACreative-Tail-Animal-dog.svg&psig=AOvVaw0vXYuWkrVKcCTyiRDvL4_b&ust=1595464013543000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCOid0OTM3-oCFQAAAAAdAAAAABAD",
        "https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.flaticon.com%2Fkr%2Ffree-icon%2Fhamster_196817&psig=AOvVaw0vXYuWkrVKcCTyiRDvL4_b&ust=1595464013543000&source=images&cd=vfe&ved=0CAIQjRxqFwoTCOid0OTM3-oCFQAAAAAdAAAAABAV",
        "https://image.flaticon.com/icons/svg/196/196813.svg"]
   
    // 토스트 알림 메시지 내용
    let messages: Array<String> = ["test",
                                   "test",
                                   "test",
                                   "test"]
    
    
    
    
    @IBOutlet weak var diseaseTableView: UITableView!
    
        override func viewDidLoad() {
            super.viewDidLoad()

            
            
        }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "diseaseTableViewCell", for: indexPath) as! DiseaseTableViewCell
        cell.labelName.text = names[indexPath.row]
        cell.labelAnimal.text = String(animals[indexPath.row])
        cell.imageAnimal.sd_setImage(with: URL(string: self.images[indexPath.row]), completed: nil)
        cell.selectionStyle = .none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    //        tableView.deselectRow(at: indexPath, animated: false)  // 눌려있지 않고 누르고 있을때만 음영표시
            print("\(indexPath.row)줄이 선택됨.")
            self.view.makeToast(messages[indexPath.row], duration: 2.0, position: .bottom)
        }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
            print("\(indexPath.row)줄이 선택됨")
            self.view.makeToast(self.messages[indexPath.row], duration: 2.0, position: .bottom)
        }

}
