
import UIKit

class ReviewViewController: UIViewController {

    @IBOutlet weak var reviewImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.layoutIfNeeded()
        self.reviewImage.layer.cornerRadius = self.reviewImage.frame.width/2.0
        self.reviewImage.clipsToBounds = true

    }
    

    

}
