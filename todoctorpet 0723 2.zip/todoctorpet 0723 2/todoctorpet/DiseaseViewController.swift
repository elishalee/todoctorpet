
import UIKit
import Toast_Swift
import SDWebImage

class DiseaseViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    // labelName 레이블 출력 내용
    let names: Array<String> = ["고양이 독감",
                                "홍역",
                                "test",
                                "test",
                                "범백혈구 감소증",
                                "파보 장염",
                                "test",
                                "test",
                                "외부 기생충 감염",
                                "코로나 장염",
                                "test",
                                "test",
                                "내부 기생충 감염",
                                "켄넬코프",
                                "test",
                                "test",
                                "만성 신부전증(CRF)",
                                "심장사상충",
                                "test",
                                "test",
                                "백혈병",
                                "광견병",
                                "test",
                                "test",
                                "전염성 복막염(FIP)",
                                "전염성 간염",
                                "test",
                                "test",
                                "톡소플라즈마증",
                                "강아지 녹내장",
                                "test",
                                "test",
                                "고양이 당뇨병",
                                "슬개골 탈구",
                                "test",
                                "test",
                                "갑상선 기능 항진증",
                                "추간판 탈출증",
                                "test",
                                "test"]
    
    // labelAnimal 레이블 출력 내용
    let animals: Array<NSString> = ["고양이",
                                   "개",
                                   "햄스터",
                                   "토끼",
                                   "고양이",
                                   "개",
                                   "햄스터",
                                   "토끼",
                                    "고양이",
                                    "개",
                                    "햄스터",
                                    "토끼",
                                    "고양이",
                                    "개",
                                    "햄스터",
                                    "토끼",
                                    "고양이",
                                    "개",
                                    "햄스터",
                                    "토끼",
                                    "고양이",
                                    "개",
                                    "햄스터",
                                    "토끼",
                                    "고양이",
                                    "개",
                                    "햄스터",
                                    "토끼",
                                    "고양이",
                                    "개",
                                    "햄스터",
                                    "토끼",
                                    "고양이",
                                    "개",
                                    "햄스터",
                                    "토끼",
                                    "고양이",
                                    "개",
                                    "햄스터",
                                    "토끼"]
    
    // imageAnimal 이미지뷰 출력 이미지
    let images: Array<String> =
        ["https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png",
        "https://www.kindpng.com/picc/m/29-299509_transparent-small-red-heart-png-small-red-heart.png"]
   
    // 토스트 알림 메시지 내용
    let messages: Array<String> = ["고양이 독감은 일반적인 감기가 아니라 헤르페스나 칼리시 바이러스 또는 다양한 박테리아를 통해 눈과 입 그리고 기도에 병증을 나타내며 악화되면 목숨을 잃을 수도 있는 질병이다. (증상 : 재채기와 콧물, 끈적끈적한 눈꼽, 식욕부진, 고열)",
                                   "전염성이 강하고 폐사율이 높은 바이러스성 전렴병으로, 공기 중으로도 감염이 된다. 특히 나이가 어린 강아지는 대다수 사망에 이르는 무서운 질병이다. (증상 : 눈꼽, 설사, 구토, 호흡기증상(켁켁거림)",
                                   "test3",
                                   "test4",
                                   "파보바이러스로 전염되며 다른 고양이에게서 또는 배설물과의 접촉, 벼룩이나 진드기를 통해 간접 전염이 된다. 고전염성 질병으로 분류되며 잠복기간이 있어 감염 후 짧게는 일주일, 길게는 세 달 이후에 첫 증상이 발현된다. (증상 : 담즙색의 구토, 고열(혹은 저체온), 식욕부진, 무기력, 혈변, 탈수)",
                                   "어린 강아지는 거의 폐사에 이르는 무서운 질병이다. 주로 다른 강아지의 변을 통해 감염된다. (증상 : 설사를 주증으로 하는 장염형(구토, 심한 설사), 심근염형(단시간에 호흡곤란이 와서 폐사)",
                                   "test7",
                                   "test8",
                                    "털이 많은 고양이는 다양한 기생충에 감염될 수 있는데, 특히 외출 고양이일 경우 감염 확률이 높아진다. 주요 감염원으로는 진드기, 이, 벼룩 그리고 옴 등이 있다. (증상 : 심한 가려움, 탈모, 비듬)",
                                    "코로나 바이러스가 장에 침투하여 설사를 주증으로 하는 장염이 발생한다. 비교적 치료가 쉬우며 초기에 발견 시 적절한 치료가 이루어지면 높은 생존률을 보인다. 주로 다른 강아지의 변을 통해 감염된다. (증상 : 구토, 발열, 악취나는 설사)",
                                    "test3",
                                    "test4",
                                    "내부 기생충은 주로 고양이 소장에 번식하는데, 회충, 촌충, 십이지장충 등이 있으며 5~10cm 정도의 길이를 보인다. 이 기생충은 사람에게도 감염되므로 동반 구충이 권장된다. 감염원으로는 사냥한 작은 동물이나 다른 동물의 변 그리고 드물게 어미 고양이의 젖 등이 있다. (증상 : 식욕부진, 푸석푸석한 털, 체중감소, 구토, 대변에 기생충이 섞여 나옴)",
                                    "여러가지 바이러스에 기인한 기관지염을 말하며 콧물과 발작성 기침을 일으키는 질병이다. 3차 예방접종부터 함께 접종받는 것을 권장한다. (증상 : 콧물, 발작성기침)",
                                    "test7",
                                    "test8",
                                    "특히 나이가 많은 고양이에게 흔히 발생한다. 신장 기능이 점점 약화되다가 사망에 이르게 되는 질병이다. (증상 : 갈증, 배뇨 증가, 식욕부진, 무기력증, 윤기없는 털, 구토, 체중감소, 강한 입냄새, 과호흡, 경련, 발작, 설사, 저체온)",
                                    "심장과 폐의 혈관 속에 모기가 알을 낳아 기생충이 감염되는 질병이다. 아무런 증상 없이 갑자기 심장 장애를 일으켜 급사하는 경우도 있으며 최근 개발된 검사키트로는 혈액 몇 방울로도 단시간만에 감염 여부를 알 수가 있다. 6개월 주기로 예방하는 것을 권장한다. (증상 : 기침, 호흡곤란, 식욕부진, 혈뇨, 무증상)",
                                    "test3",
                                    "test4",
                                    "사람의 백혈병과 달리 바이러스로 전염되는데, 사람이나 개에게 영향을 주지 않는다. 전염 속도가 매우 빠르며 피, 소변 그리고 어미 고양이의 젖으로도 전파된다. 이 병에 감염되면 99%가 5년 이내에 목숨을 잃는다. (증상 : 발열, 무기력증, 구토, 설사, 빈혈, 식욕부진, 체중감소)",
                                    "모든 온혈동물들에게 발생하며 폐사율이 높은 전염병이다. 광견병에 걸린 동물의 침을 통해 쉽게 감염이 되며 주로 야생동물에게서 옮는다. 6개월 주기로 예방하는 것을 권장한다. (증상 : 발열, 발작, 침을 과하게 흘림, 공격성 증가, 공수병)",
                                    "test7",
                                    "test8",
                                    "코로나 바이러스로 유발되는데 고양이 질병 중에 가장 치명적이고 치료가 어려우며 감염경로나 원인, 치료법에 대해서도 아직 확실하게 밝혀진 바가 없다. 증상이 매우 천천히 나타나고, 진행도 느려 세심한 관찰을 요하는 질병이다. 주로 많은 고양이들이 함께 살거나 불결하고 영양부족이 의심되는 환경에서 자주 발병하므로 다른 동물의 변이나 침 등으로 감염된다고 볼 수 있다. (증상 : 복수 및 흉수가 참, 삭욕부진, 무기력, 설사, 윤기없는 털, 용변실수)",
                                    "주로 간에 영향을 끼치는 바이러스성 질환이다. 감염된 개의 변이나 소변으로 감염되거나 직접적인 접촉 또는 오염된 사료나 물 등으로 전염된다. 초기에 발견하면 통원치료가 가능하기도 하지만, 영양 및 수분 보충, 2차 세균감염을 방지하기 위한 주사 등의 지속적인 관심이 필요하다. (증상 : 고열, 식욕부진, 구토, 복통, 설사, 종종 혈변, 황달, 눈병, 각막염)",
                                    "test3",
                                    "test4",
                                    "고양이 장에 있는 있는 기생충인 톡소플라즈마 곤디에 의해 유발되어 고양이의 변이나 날고기, 설익힌 고기를 통해 전파되는데, 실내에만 사는 집고양이에게는 드물게 발견되며 외출고양이나 길고양이에게서 발견될 수는 있으나 한국의 토양에는 톡소플라즈마가 살아남기 어려운 환경이기 때문에 큰 위험이 없다. (증상 : 호흡곤란, 발열, 식욕부진, 갈증)",
                                    "눈에 뿌연 막이 보이고 색이 변하며 시력이 떨어지다가 추후 실명으로 이어질 수 있는 안구 질환이다. 주로 나이가 많은 노견에게서 나타나는 증상이지만 드물게 어린 강아지에게서도 발견되는 유전병이기도 하다. 질병에 걸린 후 시간 경과 시 치료가 힘들고 회복이 거의 불가능하다. 또한, 주로 눈이 큰 견종에게 흔한 질병이다. (증상 : 냄새를 동반한 과도한 눈물 및 눈꼽)",
                                    "test7",
                                    "test8",
                                    "주로 기름진 음식과 운동부족 등이 원인으로 혈당이 높아지고 면역체계에 이상을 불러오고 적절한 치료가 동반되지 않으면 죽음에까지 이르게 된다. (증상 : 잘 먹는데도 불구하고 체중 감소, 무기력증)",
                                    "선천적이나 후천적인 이유로 개의 무릎뼈가 어긋나는 증상으로, 정상적으로 걷거나 뛰는 것이 어려워진다. 특히 주로 몸집이 작은 소형견 강아지에게 발견되는 경우가 많으며 별다른 증상이 없다가 추후 성견이 되고나서 발생하는 경우도 있다. (증상 : 걸음에 힘이 없음, 절뚝거림, 불규칙적인 걸음걸이, 무릎에서 소리가 남)",
                                    "test3",
                                    "test4",
                                    "심박수가 빨라지고 호흡이 가빠지며 특히 나이 든 수컷 고양이에게서 자주 발생하는데, 신부전이나 심장병으로 이어지는 경우가 많아서 조심해야 할 질병이다. (증상 : 구토, 체중감소, 활동성 증가, 윤기 없는 털, 헐떡거림, 호흡곤란, 발열, 식욕증가, 설사)",
                                    "나이가 들면서 추간판 퇴행으로 생기거나 관절염, 척추염 또는 선천적으로 발생하기도 한다. 또한 외부 충격, 유전, 과체중 등으로 인해 디스크가 발생할 수 있가도 하다. 특히 주로 닥스훈트, 웹시코기와 같이 다리가 짧고 허리가 긴 견종들에 주로 발병하는 질병이다. (증상 : 등, 목 부위를 만지면 예민하게 반응, 활동성 감소, 스킨쉽 거부, 오랜시간 웅크림, 부자연스러운 보행, 배변 및 배뇨 실수)",
                                    "test7",
                                    "test8"]
    
    
    
    
    @IBOutlet weak var diseaseTableView: UITableView!
    
        override func viewDidLoad() {
            super.viewDidLoad()

            
            
        }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "diseaseTableViewCell", for: indexPath) as! DiseaseTableViewCell
        cell.labelName.text = names[indexPath.row]
        cell.labelAnimal.text = String(animals[indexPath.row])
        cell.imageAnimal.sd_setImage(with: URL(string: self.images[indexPath.row]), completed: nil)
        cell.selectionStyle = .none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    //        tableView.deselectRow(at: indexPath, animated: false)  // 눌려있지 않고 누르고 있을때만 음영표시
            print("\(indexPath.row)줄이 선택됨.")
            self.view.makeToast(messages[indexPath.row], duration: 2.0, position: .bottom)
        }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
            print("\(indexPath.row)줄이 선택됨")
            self.view.makeToast(self.messages[indexPath.row], duration: 2.0, position: .bottom)
        }

}
